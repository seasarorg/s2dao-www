SELECT * FROM emp
/*BEGIN*/
WHERE /*IF dto.job != "789"*/job = /*dto.job*/'CLERK'/*END*/
/*END*/