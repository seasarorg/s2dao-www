select * 
  from EMP
 where ENAME = /*$arg*/
;

