package org.seasar.dao.annotation.backport175.impl;

import java.util.List;
/**
 * @org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee2.class)
 */
public interface Employee2Dao {
	public List getAllEmployees();
}
