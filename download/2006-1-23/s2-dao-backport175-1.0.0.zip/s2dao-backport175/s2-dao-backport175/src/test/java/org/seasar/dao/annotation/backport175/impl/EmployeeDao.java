package org.seasar.dao.annotation.backport175.impl;

import java.util.List;
/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee.class)
 */
public interface EmployeeDao {
	
	public List getAllEmployees();
	
	public Employee[] getAllEmployeeArray();
	
	/**
	 * @org.seasar.dao.annotation.backport175.Arguments({"empno"})
	 * @param empno
	 * @return
	 */
	public Employee getEmployee(int empno);
	
	public int getCount();
	
	public void update(Employee employee);
	
	public Employee[] getEmployeesByDeptno(int deptno);
}
