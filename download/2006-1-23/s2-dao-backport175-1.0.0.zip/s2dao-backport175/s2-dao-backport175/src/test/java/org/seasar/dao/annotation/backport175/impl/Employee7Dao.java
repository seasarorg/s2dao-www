package org.seasar.dao.annotation.backport175.impl;

/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee5.class)
 */

public interface Employee7Dao {

	/**
	 * @org.seasar.dao.annotation.backport175.Sql("SELECT COUNT(*) FROM emp")
	 * @return
	 */
	public int getCount();
	
	/**
	 * @org.seasar.dao.annotation.backport175.Sql("DELETE FROM emp WHERE empno=?")
	 * @param empno
	 * @return
	 */
	public int deleteEmployee(int empno);
}
