package org.seasar.dao.annotation.backport175.impl;
/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee4.class)
 */
public interface Employee4Dao {
	
	/**
	 *@org.seasar.dao.annotation.backport175.Arguments({"empno"}) 
	 */
	public Employee4 getEmployee(int empno);
}
