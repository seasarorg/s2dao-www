package org.seasar.dao.annotation.backport175.impl;

import java.util.List;
/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee3.class)
 */
public interface Employee3Dao {
	
	public List getEmployees(Employee3 dto);
	
	/**
	 * @org.seasar.dao.annotation.backport175.Query("ORDER BY empno")
	 * @param dto
	 * @return
	 */
	public List getEmployees2(Employee3 dto);
}
