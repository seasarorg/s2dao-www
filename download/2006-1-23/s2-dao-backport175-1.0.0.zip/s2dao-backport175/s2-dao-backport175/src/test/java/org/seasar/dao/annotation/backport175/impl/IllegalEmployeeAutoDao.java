package org.seasar.dao.annotation.backport175.impl;

/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee5.class)
 */
public interface IllegalEmployeeAutoDao {
	
	public void insertIllegal(int empno);
}
