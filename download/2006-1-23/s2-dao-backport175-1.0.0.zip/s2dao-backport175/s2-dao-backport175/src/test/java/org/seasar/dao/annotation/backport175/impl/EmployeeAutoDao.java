package org.seasar.dao.annotation.backport175.impl;

import java.util.List;

/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee.class)
 */
public interface EmployeeAutoDao {

	/**
	 * @org.seasar.dao.annotation.backport175.Arguments({"deptno"})
	 * 
	 * @org.seasar.dao.annotation.backport175.Query("deptno asc, empno desc")
	 */
	public List getEmployeeByDeptno(int deptno);
	
	/**
	 * @param minSal
	 * @param maxSal
	 * @org.seasar.dao.annotation.backport175.Query("sal BETWEEN ? AND ? ORDER BY empno")
	 */
	public List getEmployeesBySal(Float minSal, Float maxSal);
	
	/**
	 * 
	 * @org.seasar.dao.annotation.backport175.Arguments({"enames","jobs"})
	 * @org.seasar.dao.annotation.backport175.Query("ename IN #*enames*#('SCOTT','MARY') AND job IN #*jobs*#('ANALYST', 'FREE')")
	 * @return
	 */
	public List getEmployeesByEnameJob(List enames, List jobs);
	
	public List getEmployeesBySearchCondition(EmployeeSearchCondition dto);

	/**
	 *@org.seasar.dao.annotation.backport175.Query("department.dname = #*dto.department.dname*#'RESEARCH'") 
	 */
	public List getEmployeesBySearchCondition2(EmployeeSearchCondition dto);
	
	public List getEmployeesByEmployee(Employee dto);
	
	/**
	 * @org.seasar.dao.annotation.backport175.Arguments({"empno"})
	 */
	public Employee getEmployee(int empno);

	public void insert(Employee employee);
	
	/**
	 * @org.seasar.dao.annotation.backport175.NoPersistentProperty({"job", "mgr", "hiredate", "sal", "comm", "deptno"})
	 */
	public void insert2(Employee employee);
		
	/**
	 * @org.seasar.dao.annotation.backport175.PersistentProperty({"deptno"})
	 * @param employee
	 */
	public void insert3(Employee employee);
	
	public void insertBatch(Employee[] employees);
	
	public void update(Employee employee);
	
	/**
	 * @org.seasar.dao.annotation.backport175.NoPersistentProperty({"job", "mgr", "hiredate", "sal", "comm", "deptno"})
	 * @param employee
	 */
	public void update2(Employee employee);
	
	/**
	 * @org.seasar.dao.annotation.backport175.PersistentProperty({"deptno"})
	 * @param employee
	 */
	public void update3(Employee employee);
	
	public void updateBatch(Employee[] employees);
	
	public void delete(Employee employee);
	
	public void deleteBatch(Employee[] employees);
}
