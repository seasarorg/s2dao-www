package org.seasar.dao.annotation.backport175.impl;

import java.lang.reflect.Method;

import org.codehaus.backport175.reader.Annotations;
import org.codehaus.backport175.reader.ReaderException;
import org.seasar.dao.DaoAnnotationReader;
import org.seasar.dao.annotation.backport175.Arguments;
import org.seasar.dao.annotation.backport175.NoPersistentProperty;
import org.seasar.dao.annotation.backport175.PersistentProperty;
import org.seasar.dao.annotation.backport175.Query;
import org.seasar.dao.annotation.backport175.S2Dao;
import org.seasar.dao.annotation.backport175.Sql;
import org.seasar.framework.beans.BeanDesc;

public class DaoAnnotationReaderImpl implements DaoAnnotationReader {
	private BeanDesc daoBeanDesc_;
	private Class daoClass_;
	public DaoAnnotationReaderImpl(BeanDesc daoBeanDesc) {
		daoBeanDesc_ = daoBeanDesc;
		daoClass_ = daoBeanDesc.getBeanClass();
		boolean readable = false;
		do{
			try {
				Annotations.isAnnotationPresent(S2Dao.class,daoClass_);
				readable = true;
			} catch (ReaderException e) {
				daoClass_ = daoClass_.getSuperclass();
			}
		}while(!readable);
		
	}
	public String getQuery(Method method) {
		Query query = (Query) Annotations.getAnnotation(Query.class,method);
		if(query==null){
			return null;
		}
		
		return query.value().replaceAll("#\\*","/*").replaceAll("\\*#","*/");
	}

	public String[] getArgNames(Method method) {
		Arguments arg = (Arguments) Annotations.getAnnotation(Arguments.class,method);
		return (arg!=null)?arg.value():new String[0];
	}
	public Class getBeanClass() {
		if(Annotations.isAnnotationPresent(S2Dao.class,daoClass_)){
			S2Dao s2dao = (S2Dao) Annotations.getAnnotation(S2Dao.class,daoClass_);
			return s2dao.bean();
		}
		return null;
	}

	public String[] getNoPersistentProps(Method method) {
		NoPersistentProperty npp = (NoPersistentProperty) Annotations.getAnnotation(NoPersistentProperty.class,method);
		return (npp!=null)?npp.value():null;
	}

	public String[] getPersistentProps(Method method) {
		PersistentProperty pp = (PersistentProperty) Annotations.getAnnotation(PersistentProperty.class,method);
		return (pp!=null)?pp.value():null;
	}

	public String getSQL(Method method, String suffix) {
		Sql sql = (Sql) Annotations.getAnnotation(Sql.class,method);
		return (sql!=null)?sql.value():null;
	}

}
