package org.seasar.dao.annotation.backport175;


public interface Arguments {
    /**
     * @org.codehaus.backport175.DefaultValue ({})
     */
	String[] value();
}
