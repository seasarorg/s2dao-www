package org.seasar.dao.annotation.backport175.impl;

import org.codehaus.backport175.reader.Annotation;
import org.codehaus.backport175.reader.Annotations;
import org.seasar.dao.BeanAnnotationReader;
import org.seasar.dao.annotation.backport175.Bean;
import org.seasar.dao.annotation.backport175.Column;
import org.seasar.dao.annotation.backport175.Id;
import org.seasar.dao.annotation.backport175.Relation;
import org.seasar.framework.beans.PropertyDesc;

public class BeanAnnotationReaderImpl implements BeanAnnotationReader {
	private Class beanClass_;
	private Bean bean_;
	public BeanAnnotationReaderImpl(Class beanClass) {
		this.beanClass_ = beanClass;
		bean_ = (Bean) Annotations.getAnnotation(Bean.class,beanClass_);		
	}
	private Annotation getPropertyAnnotation(Class clazz,PropertyDesc pd){
		Annotation a = Annotations.getAnnotation(clazz,pd.getWriteMethod());
		if(a!=null)
			return a;
		return Annotations.getAnnotation(clazz,pd.getReadMethod());		
	}
	public String getColumnAnnotation(PropertyDesc pd) {
		Column column = (Column) getPropertyAnnotation(Column.class,pd);
		return (column!=null)?column.value():null;
	}

	public String getTableAnnotation() {
		return (bean_!=null)?bean_.table():null;
	}

	public String getVersionNoProteryNameAnnotation() {
		return (bean_!=null)?bean_.versionNoProperty():null;
	}

	public String getTimestampPropertyName() {
		return (bean_!=null)?bean_.timeStampProperty():null;
	}

	public String getId(PropertyDesc pd) {
		Id id = (Id) getPropertyAnnotation(Id.class,pd);
		return (id!=null)?id.value():null;
	}

	public String[] getNoPersisteneProps() {
		if(bean_!=null && bean_.noPersistentProperty().length!=0){
			return bean_.noPersistentProperty();
		}
		return null;
	}

	public boolean hasRelationNo(PropertyDesc pd) {
		Relation rel = (Relation) getPropertyAnnotation(Relation.class,pd);
		return (rel!=null);
	}

	public int getRelationNo(PropertyDesc pd) {
		Relation rel = (Relation) getPropertyAnnotation(Relation.class,pd);
		return (rel!=null)?rel.relationNo():0;
	}

	public String getRelationKey(PropertyDesc pd) {
		Relation rel = (Relation) getPropertyAnnotation(Relation.class,pd);
		return (rel!=null)?rel.relationKey():null;
	}

}
