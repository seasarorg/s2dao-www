package org.seasar.dao.annotation.backport175;


public interface NoPersistentProperty {
	String[] value();
}
