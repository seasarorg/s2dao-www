package org.seasar.dao.annotation.backport175;


public interface Sql {
	String value();
}
