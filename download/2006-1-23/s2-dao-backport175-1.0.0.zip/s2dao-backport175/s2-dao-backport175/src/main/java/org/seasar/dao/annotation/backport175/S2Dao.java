package org.seasar.dao.annotation.backport175;


public interface S2Dao {
	Class bean();
}
