package org.seasar.dao.annotation.backport175;

public interface Id {
    /**
     * @org.codehaus.backport175.DefaultValue ("assigned")
     */
	String value();

}
