package org.seasar.dao.annotation.backport175;


public interface Query {
	String value();
}
