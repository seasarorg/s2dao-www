package org.seasar.dao.annotation.backport175;


public interface Bean {
    /**
     * @org.codehaus.backport175.DefaultValue ("")
     */
	String table();
    /**
     * @org.codehaus.backport175.DefaultValue ({})
     */
	String[] noPersistentProperty();
    /**
     * @org.codehaus.backport175.DefaultValue ("versionNo")
     */
	String versionNoProperty();
    /**
     * @org.codehaus.backport175.DefaultValue ("timestamp")
     */
	String timeStampProperty();
}
