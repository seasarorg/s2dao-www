package examples.dao.backport175;


import java.util.List;

public interface Employee2Dao {
	
	public List getEmployees(String ename);


	public Employee getEmployee(int empno);

}
