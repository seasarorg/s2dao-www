package examples.dao.backport175;

/**
 * @org.seasar.dao.annotation.backport175.S2Dao (
 * 	bean=examples.dao.backport175.Department.class)
 */
public interface DepartmentDao {
	public void insert(Department department);
	
	public void update(Department department);
	
	public void delete(Department department);
}
