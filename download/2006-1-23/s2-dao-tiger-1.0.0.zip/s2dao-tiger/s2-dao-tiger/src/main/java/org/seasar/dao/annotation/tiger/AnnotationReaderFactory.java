package org.seasar.dao.annotation.tiger;

public class AnnotationReaderFactory {

}
