package org.seasar.dao.annotation.tiger;

public enum IdType {
	IDENTITY,SEQUENCE,ASSIGNED
}
