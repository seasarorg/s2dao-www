package org.seasar.dao.impl;

public interface EmployeeExDao extends EmployeeDao {

}
