package org.seasar.dao;

/**
 * @author higa
 *
 */
public interface SqlParser {
	
	public Node parse();

}
