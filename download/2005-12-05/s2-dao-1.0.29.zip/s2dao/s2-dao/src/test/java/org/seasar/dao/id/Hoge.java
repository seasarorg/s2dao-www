package org.seasar.dao.id;

/**
 * @author higa
 *
 */
public class Hoge {

	private int id = -1;
	
	public Hoge() {
	}

	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
}
