package org.seasar.dao.impl;

public interface IllegalEmployeeAutoDao {

	public Class BEAN = Employee.class;
	
	public void insertIllegal(int empno);
}
