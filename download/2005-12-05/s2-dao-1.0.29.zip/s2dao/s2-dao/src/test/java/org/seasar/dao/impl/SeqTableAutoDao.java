package org.seasar.dao.impl;

public interface SeqTableAutoDao {

	public Class BEAN = SeqTable.class;
	
	public void insert(SeqTable seqTable);
}
