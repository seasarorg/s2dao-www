INSERT INTO NO_PK_TABLE VALUES (/*dto.aaa*/'Z', /*dto.bbb*/99)
