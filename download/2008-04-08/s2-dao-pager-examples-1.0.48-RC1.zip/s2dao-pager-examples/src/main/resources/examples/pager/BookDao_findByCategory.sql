SELECT *
FROM book
WHERE category = /*category*/'Java'
ORDER BY book.ID