select * 
/*$comment*/
  from EMP
 where id = /*id*/1
;

