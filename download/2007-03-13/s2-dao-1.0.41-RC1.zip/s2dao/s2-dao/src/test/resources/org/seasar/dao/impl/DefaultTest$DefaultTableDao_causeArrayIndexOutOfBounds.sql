select * 
/*$comment*/
  from DEFAULT_TABLE
 where id = /*id*/1
;

