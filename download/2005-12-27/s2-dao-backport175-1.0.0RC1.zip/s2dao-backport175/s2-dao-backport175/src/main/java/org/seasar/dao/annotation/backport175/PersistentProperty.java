package org.seasar.dao.annotation.backport175;


public interface PersistentProperty {
	String[] value();
}
