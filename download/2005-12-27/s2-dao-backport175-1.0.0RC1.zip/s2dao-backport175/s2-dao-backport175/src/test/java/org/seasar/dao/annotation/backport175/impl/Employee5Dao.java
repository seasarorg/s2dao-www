package org.seasar.dao.annotation.backport175.impl;
/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee5.class)
 */
public interface Employee5Dao {

	/**
	 * @Arugments("empno")
	 */
	public Employee5 getEmployee(int empno);
}
