package org.seasar.dao.annotation.backport175.impl;

import java.util.List;

/**
 * @org.seasar.dao.annotation.backport175.S2Dao (
 * 	bean=org.seasar.dao.annotation.backport175.impl.DepartmentTotalSalary.class)
 */
public interface DepartmentTotalSalaryDao {

	public Class BEAN = DepartmentTotalSalary.class;

	public List getTotalSalaries();
}
