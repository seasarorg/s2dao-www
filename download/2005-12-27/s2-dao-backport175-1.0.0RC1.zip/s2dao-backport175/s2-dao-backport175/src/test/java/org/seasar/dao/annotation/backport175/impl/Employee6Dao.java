package org.seasar.dao.annotation.backport175.impl;

/**
 *@org.seasar.dao.annotation.backport175.S2Dao(bean=org.seasar.dao.annotation.backport175.impl.Employee5.class)
 */
public interface Employee6Dao {

	/**
	 * @org.seasar.dao.annotation.backport175.Query("#*IF $dto.orderByString != null*#order by #*$dto.orderByString*#ENAME #*END*#") 
	 * @param dto
	 * @return
	 */
	public Employee[] getEmployees(EmployeeSearchCondition dto);
}
