package examples.dao.backport175;


import java.util.List;

/**
 * 
 * @author �㌴�@�c�O
 * @org.seasar.dao.annotation.backport175.S2Dao(
 * bean=examples.dao.backport175.Employee.class)
 */
public interface EmployeeDao {
	
	public List getAllEmployees();
	
	/**
	 * @org.seasar.dao.annotation.backport175.Arguments({"empno"})
	 * @param empno
	 * @return
	 */
	public Employee getEmployee(int empno);
	
	/**
	 * @org.seasar.dao.annotation.backport175.Sql(
	 * "SELECT count(*) FROM emp")
	 * @param empno
	 * @return
	 */
	public int getCount();
		
	/**
	 * @org.seasar.dao.annotation.backport175.Arguments({"job","deptno"})
	 * @param empno
	 * @return
	 */
	public List getEmployeeByJobDeptno(String job, Integer deptno);
	
	public int update(Employee employee);
}
