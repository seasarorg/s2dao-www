package examples.dao;

import java.util.List;

public interface Employee2Dao {
	
	public List getEmployees(String ename);


	public Employee getEmployee(int empno);

}
