package org.seasar.dao.impl;

public interface IdentityTableAutoDao {

	public Class BEAN = IdentityTable.class;
	
	public void insert(IdentityTable identityTable);
}
