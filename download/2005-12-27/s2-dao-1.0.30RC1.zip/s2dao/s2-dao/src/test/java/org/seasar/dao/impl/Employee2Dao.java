package org.seasar.dao.impl;

import java.util.List;

public interface Employee2Dao {

	public Class BEAN = Employee2.class;

	public List getAllEmployees();
}
