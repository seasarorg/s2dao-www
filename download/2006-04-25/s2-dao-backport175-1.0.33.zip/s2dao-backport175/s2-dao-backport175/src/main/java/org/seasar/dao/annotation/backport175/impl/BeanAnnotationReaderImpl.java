/*
 * Copyright 2004-2006 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.dao.annotation.backport175.impl;

import org.codehaus.backport175.reader.Annotation;
import org.codehaus.backport175.reader.Annotations;
import org.seasar.dao.BeanAnnotationReader;
import org.seasar.dao.annotation.backport175.Bean;
import org.seasar.dao.annotation.backport175.Column;
import org.seasar.dao.annotation.backport175.Id;
import org.seasar.dao.annotation.backport175.Relation;
import org.seasar.dao.annotation.backport175.ValueType;
import org.seasar.framework.beans.PropertyDesc;

public class BeanAnnotationReaderImpl implements BeanAnnotationReader {
    private Class beanClass_;
    private Bean bean_;

    public BeanAnnotationReaderImpl(Class beanClass) {
        this.beanClass_ = beanClass;
        bean_ = (Bean) Annotations.getAnnotation(Bean.class, beanClass_);
    }

    private Annotation getPropertyAnnotation(Class clazz, PropertyDesc pd) {
        if (pd.getWriteMethod() != null) {
            Annotation annotation = Annotations.getAnnotation(clazz, pd
                .getWriteMethod());
            if (annotation != null) {
                return annotation;
            }
        }
        if (pd.getReadMethod() != null) {
            return Annotations.getAnnotation(clazz, pd.getReadMethod());
        }
        return null;
    }

    public String getColumnAnnotation(PropertyDesc pd) {
        Column column = (Column) getPropertyAnnotation(Column.class, pd);
        return (column != null) ? column.value() : null;
    }

    public String getTableAnnotation() {
        return (bean_ != null) ? bean_.table() : null;
    }

    public String getVersionNoProteryNameAnnotation() {
        return (bean_ != null) ? bean_.versionNoProperty() : null;
    }

    public String getTimestampPropertyName() {
        return (bean_ != null) ? bean_.timeStampProperty() : null;
    }

    public String getId(PropertyDesc pd) {
        Id id = (Id) getPropertyAnnotation(Id.class, pd);
        return (id != null) ? id.value() : null;
    }

    public String[] getNoPersisteneProps() {
        if (bean_ != null && bean_.noPersistentProperty().length != 0) {
            return bean_.noPersistentProperty();
        }
        return null;
    }

    public boolean hasRelationNo(PropertyDesc pd) {
        Relation rel = (Relation) getPropertyAnnotation(Relation.class, pd);
        return (rel != null);
    }

    public int getRelationNo(PropertyDesc pd) {
        Relation rel = (Relation) getPropertyAnnotation(Relation.class, pd);
        return (rel != null) ? rel.relationNo() : 0;
    }

    public String getRelationKey(PropertyDesc pd) {
        Relation rel = (Relation) getPropertyAnnotation(Relation.class, pd);
        return (rel != null) ? rel.relationKey() : null;
    }

    public Class getValueType(PropertyDesc pd) {
        ValueType valueType = (ValueType) getPropertyAnnotation(
            ValueType.class, pd);
        return (valueType != null) ? valueType.value() : null;
    }

}
