SELECT *
FROM book
WHERE category = /*category*/'Java'