INSERT INTO EMP (
    /*IF dto.empno != null*/EMPNO,/*END*/
    /*IF dto.ename != null*/ENAME,/*END*/
    TSTAMP
) VALUES (
	 /* comment */
	/*IF dto.empno != null*//*dto.empno*/null,/*END*/
	/*IF dto.ename != null*//*dto.ename*/null,/*END*/
	null
	 /* ? in comment */
)
