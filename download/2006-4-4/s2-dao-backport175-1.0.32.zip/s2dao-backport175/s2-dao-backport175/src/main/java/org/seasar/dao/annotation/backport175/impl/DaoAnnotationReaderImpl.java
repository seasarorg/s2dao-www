/*
 * Copyright 2004-2006 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.dao.annotation.backport175.impl;

import java.lang.reflect.Method;

import org.codehaus.backport175.reader.Annotations;
import org.codehaus.backport175.reader.ReaderException;
import org.seasar.dao.DaoAnnotationReader;
import org.seasar.dao.annotation.backport175.Arguments;
import org.seasar.dao.annotation.backport175.NoPersistentProperty;
import org.seasar.dao.annotation.backport175.PersistentProperty;
import org.seasar.dao.annotation.backport175.Procedure;
import org.seasar.dao.annotation.backport175.Query;
import org.seasar.dao.annotation.backport175.S2Dao;
import org.seasar.dao.annotation.backport175.Sql;
import org.seasar.framework.beans.BeanDesc;

public class DaoAnnotationReaderImpl implements DaoAnnotationReader {
	private BeanDesc daoBeanDesc_;
	private Class daoClass_;
	public DaoAnnotationReaderImpl(BeanDesc daoBeanDesc) {
		daoBeanDesc_ = daoBeanDesc;
		daoClass_ = daoBeanDesc.getBeanClass();
		boolean readable = false;
		do{
			try {
				Annotations.isAnnotationPresent(S2Dao.class,daoClass_);
				readable = true;
			} catch (ReaderException e) {
				daoClass_ = daoClass_.getSuperclass();
			}
		}while(!readable);
		
	}
	public String getQuery(Method method) {
		Query query = (Query) Annotations.getAnnotation(Query.class,method);
		if(query==null){
			return null;
		}
		
		return query.value().replaceAll("#\\*","/*").replaceAll("\\*#","*/");
	}
	public String getStoredProcedureName(Method method) {
		Procedure p = (Procedure) Annotations.getAnnotation(Procedure.class,method);
		return (p!=null)?p.value():null;
	}

	public String[] getArgNames(Method method) {
		Arguments arg = (Arguments) Annotations.getAnnotation(Arguments.class,method);
		return (arg!=null)?arg.value():new String[0];
	}
	public Class getBeanClass() {
		if(Annotations.isAnnotationPresent(S2Dao.class,daoClass_)){
			S2Dao s2dao = (S2Dao) Annotations.getAnnotation(S2Dao.class,daoClass_);
			return s2dao.bean();
		}
		return null;
	}

	public String[] getNoPersistentProps(Method method) {
		NoPersistentProperty npp = (NoPersistentProperty) Annotations.getAnnotation(NoPersistentProperty.class,method);
		return (npp!=null)?npp.value():null;
	}

	public String[] getPersistentProps(Method method) {
		PersistentProperty pp = (PersistentProperty) Annotations.getAnnotation(PersistentProperty.class,method);
		return (pp!=null)?pp.value():null;
	}

	public String getSQL(Method method, String suffix) {
		Sql sql = (Sql) Annotations.getAnnotation(Sql.class,method);
		return (sql!=null)?sql.value():null;
	}

}
